#ifndef SET_H
#define SET_H

class Set
{
public;
int len;
int set_thing [];
 Set  (int len);
 Set (const Set &obj);


}